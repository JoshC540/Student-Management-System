//Joshua Cronin R00200811
package Model;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class StudentList implements Serializable {
	private ArrayList <Student> students;

	 public StudentList(){ 
		 students = new ArrayList <Student>();
	 }
	 
	 //Returns the list
	 public ArrayList<Student> getList(){
	     return students;
	 }

	 //Adds a student
	public void addStudent(Student s)
	{
		students.add(s);
	}
	
	//Gets a Student based off of the passed in value
	public Student getStudent(int i)
	{
		if ((i>-1) && (i < students.size()))
    		return students.get (i);
		return null;
	}
	
	//Gets a Student based off of their name
	public Student getStudentByName(String name)
	{
		for (int i = 0 ; i< students.size(); i++)
			if (getStudent(i).getName().equals(name))
			    return students.get(i);
			return null;
	}
	
	//Returns the size of the list
	public int getSize (){
		return students.size();
	}
	
	//Removes a student based off the passed in name
	public void remStudentByName(String name)
	{
		for (int i = 0 ; i< students.size(); i++)
			if (getStudent(i).getName().equals(name))
			    students.remove(i);
	}
	
	//Saves the list
	public void saveList() {
		try {
			ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("students.txt"));
			 {
	             os.writeObject(students);
	            }
			 os.close();
		} catch (Exception ex) {
			 System.out.println("could not save");
		     ex.printStackTrace();
		}
	}
	
	//Loads list
	public void loadAllList(){
		  try
		   {
		     ObjectInputStream is = new ObjectInputStream(new FileInputStream("students.txt"));  
		     students = (ArrayList<Student>) is.readObject();
		     System.out.println("The list has "+students.size()+" students in it\n");
		     is.close() ;       
		   } 
		   catch (Exception ex) {
		     System.out.println("could not load");
		     ex.printStackTrace();
		   		}
		   }
	
}