//Joshua Cronin R00200811
package Model;

import java.io.Serializable;

public class StudentModule implements Serializable{
	private String name;
	private int grade;
	
	public StudentModule(String m, int g){
		name = m;
		grade = g;
	}

	public StudentModule(){}
	
	//@XmlElement
		public void setName(String n ){
			name = n;
		}
	
	public String getName() {
		return name;
	}
	
	//@XmlElement
	public void setGrade(int g){
		grade = g;
	}
	
	public int getGrade() {
		return grade;
	}
	
	
	 public String toString()
	 {
       String s = "Name: " + name + ", Grade: "+ grade + "\n";
	   return s;
	 }

}
