//Joshua Cronin R00200811
package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import Controller.GradeComparator;
import Controller.ModuleNameComparator;


public class ModuleList implements Serializable{
	private ArrayList <StudentModule> studentModules;

	 public ModuleList(){ 
		 studentModules = new ArrayList <StudentModule>();
	 }
	 //Returns the list
	 public ArrayList<StudentModule> getList(){
	     return studentModules;
	 }
	 
	 //Adds a Module
	public void addModule(StudentModule m)
	{
		studentModules.add(m);
	}
	
	//returns the module at position i
	public StudentModule getModule(int i)
	{
		if ((i>-1) && (i < studentModules.size()))
    		return studentModules.get(i);
		return null;
	}
	
	//Returns the size of the list
	public int getSize (){
		return studentModules.size();
	}
	
	
	public void sortByGrade() {
		GradeComparator gradeComparator = new GradeComparator();
		Collections.sort(studentModules, gradeComparator);
	}
	
	public void sortByModuleName() {
		Collections.sort(studentModules, new ModuleNameComparator());
	}

}