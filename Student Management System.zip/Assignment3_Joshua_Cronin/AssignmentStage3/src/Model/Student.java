//Joshua Cronin R00200811
package Model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Student implements Serializable {
	private String name;
	private String studentId;
	private LocalDate dateOfBirth;
	private ModuleList moduleList;
	
	public Student(String s, String id, LocalDate dOB){
		name = s;
		studentId = id;
		dateOfBirth = dOB;
		moduleList = new ModuleList(); 
	}

	public Student(){}
	
	//@XmlElement
		public void setName(String n ){
			name = n;
		}
	
	public String getName() {
		return name;
	}
	
	//@XmlElement
	public void setId(String id){
		studentId = id;
	}
	
	public String getId() {
		return studentId;
	}
	
	//@XmlElement
		public void setdOB(LocalDate dOB){
			dateOfBirth = dOB;
		}
		
		public LocalDate getdOB() {
			return dateOfBirth;
		}
		
		public void addModuleToStudent(StudentModule sm) {
			System.out.println("sm: " + sm);
			moduleList.addModule(sm);
		} 
		
		public ArrayList<StudentModule> getStudentModule() {
			return moduleList.getList();
		}
		
		public int getStudentModuleSize() {
			return moduleList.getSize();
		}
		
		public void sortModules(String sortType){
			if(sortType == "grade") {
				moduleList.sortByGrade();
			} else {
			 moduleList.sortByModuleName();
			}
		}
	
	 public String toString()
	 {
       String s = "Name: " + name + ", ID: "+ studentId + ", DOB: " + dateOfBirth + "\n";
	   return s;
	 }
}
