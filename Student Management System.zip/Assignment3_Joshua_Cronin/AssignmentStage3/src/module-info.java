module AssignmentStage3 {
	requires javafx.controls;
	requires popUpDisplay;
	
	opens application to javafx.graphics, javafx.fxml;
}
