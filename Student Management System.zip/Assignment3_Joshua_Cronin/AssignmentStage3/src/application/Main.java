//Joshua Cronin R00200811
package application;
	
import java.util.Collections;

import Controller.StudentController;
import View.ExitPopUp;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
	
	private Label enterNameText, enterIDText, enterDOBText, enterModuleText, enterGradeText, selectedStudentText, selectedStudentRecordText, moduleAddMessageLabel;
	private TextField enteredName, enteredID, enteredModule, enteredGrade;
	private Button addStudentBtn, removeBtn, listBtn, loadBtn, saveBtn, exitBtn, addModuleBtn, viewBtn;
	private TextArea listedStudents, listedRecord;
	private DatePicker calender;
	private ComboBox<String> studentComboBox, studentRecordComboBox;
	private ToggleGroup radioButtonGroup;
	private RadioButton sortByGrade, sortByName;
	
	private static StudentController studentControl  = new StudentController();
	
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("MTU Student Record System");
		
		//Labels
		enterNameText = new Label("Enter Name: ");			
		enterIDText = new Label("Enter Student ID: ");
		enterDOBText = new Label("Enter Date of Birth: ");
		selectedStudentText = new Label("Student: ");
		selectedStudentRecordText = new Label("Student:");
		enterModuleText = new Label("Enter the name of the module");
		enterGradeText = new Label("Enter the grade recieved in the module");
		moduleAddMessageLabel = new Label("");
		
		//TextFields
		enteredName = new TextField();
		enteredID = new TextField();
		enteredModule = new TextField();
		enteredGrade = new TextField();
		
		//Buttons
		addStudentBtn = new Button("Add");
		removeBtn = new Button("Remove");
		listBtn = new Button("List");
		loadBtn = new Button("Load");
		saveBtn = new Button("Save");
		exitBtn = new Button("Exit");
		addModuleBtn = new Button("Add");
		viewBtn = new Button("View");
		
		//Text Areas
		listedStudents = new TextArea();
		try {
			studentControl.loadSerializable();
		} catch(Exception e) {
			System.out.println("No saved data");
		}
		String allStudents = studentControl.getListStudent();
	 	if(studentControl.getStudentList().getList().isEmpty()) {
	 		listedStudents.setText("Students in the Application");
	 	} else {
	 		listedStudents.setText(allStudents);
	 	}
		listedStudents.setEditable(false);
		
		listedRecord = new TextArea();
		listedRecord.setEditable(false);
		
		//ComboBoxes
		studentComboBox = new ComboBox<String>();
		studentRecordComboBox = new ComboBox<String>();
		for(int i = 0; i < studentControl.getStudentList().getSize(); i++) {
			String studentName = studentControl.getStudentList().getStudent(i).getName();
			studentComboBox.getItems().add(studentName);
			studentRecordComboBox.getItems().add(studentName);
		}
		
		//DatePicker
		calender = new DatePicker();
		
		//Set up radio buttons
		radioButtonGroup = new ToggleGroup();
		sortByGrade = new RadioButton("Sort by grade");
		sortByGrade.setToggleGroup(radioButtonGroup);
		sortByGrade.setSelected(true);
		
		sortByName = new RadioButton("Sort by name");
		sortByName.setToggleGroup(radioButtonGroup);
		
		
		//Button Functionality 
		addStudentBtn.setOnAction(new EventHandler<ActionEvent>(){
			 @Override
			 public void handle(ActionEvent event) {
				 	boolean validInput = studentControl.checkForValidStudentInput(enteredName.getText().trim().isEmpty(), enteredID.getText().trim().isEmpty(), calender.getValue());
				 	if(validInput) {
				 		studentControl.addStudentToList(enteredName.getText(), enteredID.getText(), calender.getValue());
				 		enteredName.setText("");
				 		enteredID.setText("");
				 		calender.setValue(null);
				 	}
				 	else {
				 		listedStudents.setText("Please enter a name, student number and select a date");
				 	}
			 }
		 });
		
		listBtn.setOnAction(new EventHandler<ActionEvent>() {
			 @Override
			 public void handle(ActionEvent event) {
				 	String allStudents = studentControl.getListStudent();
				 	if(studentControl.getStudentList().getList().isEmpty()) {
				 		listedStudents.setText("There are no students in the list");
				 	} else {
				 		listedStudents.setText(allStudents);
				 	}
				 	
				 	//Updates Drop down menus
				 	studentComboBox.getItems().clear();
					studentRecordComboBox.getItems().clear();
				 	for(int i = 0; i < studentControl.getStudentList().getSize(); i++) {
						String studentName = studentControl.getStudentList().getStudent(i).getName();
						studentComboBox.getItems().add(studentName);
						studentRecordComboBox.getItems().add(studentName);
					}
				}
				 	
			 });
		
		removeBtn.setOnAction(e -> 
	         studentControl.removeStudentPopUp()
	    );
		
		saveBtn.setOnAction(e ->
			studentControl.saveSerializable()
		);
		
		loadBtn.setOnAction(e ->
			studentControl.loadSerializable()
		);
		
		exitBtn.setOnAction(e ->
			ExitPopUp.display(studentControl)
		);
		
		addModuleBtn.setOnAction(new EventHandler<ActionEvent>() {
			 @Override
			 public void handle(ActionEvent event) {
				 try {
					 int inputtedValue = Integer.parseInt(enteredGrade.getText());
					 String message = studentControl.checkForModuleInput(studentComboBox.getValue().isEmpty(), enteredModule.getText().trim().isEmpty(), inputtedValue);
					 if (message == "Module added successfully")
					 {
						 studentControl.addModuleToStudent(studentComboBox.getValue(), enteredModule.getText(), inputtedValue);
						 enteredModule.setText("");
						 enteredGrade.setText("");
						}
					 moduleAddMessageLabel.setText(message);
					 
				 } catch(Exception e){
					 System.out.println("Error");
					 moduleAddMessageLabel.setText("Please fill all of the fields");
				 }
			 	}
			});
		
		viewBtn.setOnAction(new EventHandler<ActionEvent>() { 
			@Override
			 public void handle(ActionEvent event) {
				RadioButton selectedRadioButton = (RadioButton) radioButtonGroup.getSelectedToggle();
				String sName = studentRecordComboBox.getValue();
				studentControl.getStudentFromList(sName);
				if(selectedRadioButton == sortByGrade) {
					studentControl.getStudentFromList(sName).sortModules("grade");
				} else {
					studentControl.getStudentFromList(sName).sortModules("name");
				}
				String allStudentsModules = studentControl.getListStudentModulesString(sName);
			 	if(allStudentsModules == "") {
			 		listedRecord.setText("There are no modules in the list");
			 	} else {
			 		listedRecord.setText("The modules taken by " + sName + " were: \n" +  allStudentsModules);
			 	}
			}
		});
		
		
		//Student Tab
		VBox formLabels = new VBox();
		formLabels.getChildren().addAll(enterNameText, enterIDText, enterDOBText);
		formLabels.setPadding(new Insets(10, 10, 10, 10));
		formLabels.setSpacing(20);
		
		VBox formTextBoxes = new VBox();
		formTextBoxes.getChildren().addAll(enteredName, enteredID, calender);
		formTextBoxes.setPadding(new Insets(10, 10, 10, 10));
		formTextBoxes.setSpacing(10);
		
		HBox form = new HBox();
		form.getChildren().addAll(formLabels, formTextBoxes);
		
		
		HBox formButtons = new HBox();
		formButtons.getChildren().addAll(addStudentBtn, removeBtn, listBtn);
		formButtons.setPadding(new Insets(10, 10, 10, 10));
		formButtons.setSpacing(10);
		formButtons.setAlignment(Pos.CENTER);
		
		HBox applicationButtons = new HBox();
		applicationButtons.getChildren().addAll(loadBtn, saveBtn, exitBtn);
		applicationButtons.setPadding(new Insets(10, 10, 10, 10));
		applicationButtons.setSpacing(10);
		applicationButtons.setAlignment(Pos.CENTER);
		
		VBox studentsBox = new VBox();
		studentsBox.getChildren().addAll(form, formButtons, listedStudents, applicationButtons);
	
		//Module Tab
		HBox studentSelection = new HBox();
		studentSelection.getChildren().addAll(selectedStudentText, studentComboBox);
		studentSelection.setPadding(new Insets(10, 10, 10, 10));
		studentSelection.setSpacing(20);
		
		HBox moduleNameEntry = new HBox();
		moduleNameEntry.getChildren().addAll(enterModuleText, enteredModule);
		moduleNameEntry.setPadding(new Insets(10, 10, 10, 10));
		moduleNameEntry.setSpacing(20);
		
		HBox moduleGradeEntry = new HBox();
		moduleGradeEntry.getChildren().addAll(enterGradeText, enteredGrade);
		moduleGradeEntry.setPadding(new Insets(10, 10, 10, 10));
		moduleGradeEntry.setSpacing(20);
		
		HBox addModuleButton = new HBox(addModuleBtn);
		addModuleButton.setPadding(new Insets(10, 10, 10, 10));
		addModuleButton.setSpacing(10);
		addModuleButton.setAlignment(Pos.CENTER);
		
		
		HBox moduleAddMessage= new HBox();
		moduleAddMessage.getChildren().add(moduleAddMessageLabel);
		addModuleButton.setPadding(new Insets(10, 10, 10, 10));
		addModuleButton.setSpacing(10);
		addModuleButton.setAlignment(Pos.CENTER);
		
		VBox moduleBox = new VBox();
		moduleBox.getChildren().addAll(studentSelection, moduleNameEntry, moduleGradeEntry, addModuleButton, moduleAddMessage);
		
		
		//Records Tab
		HBox studentRecordSelection = new HBox();
		studentRecordSelection.getChildren().addAll(selectedStudentRecordText, studentRecordComboBox);
		studentRecordSelection.setPadding(new Insets(10, 10, 10, 10));
		studentRecordSelection.setSpacing(20);
		
		HBox sortSelection = new HBox();
		sortSelection.getChildren().addAll(sortByGrade, sortByName, viewBtn);
		sortSelection.setPadding(new Insets(10, 10, 10, 10));
		sortSelection.setSpacing(20);
		
		VBox recordsBox = new VBox();
		recordsBox.getChildren().addAll(studentRecordSelection, sortSelection, listedRecord);
		
		// Tabs and tab assignment
		TabPane tabPane = new TabPane();
		Tab studentTab = new Tab("Students", studentsBox);
		Tab modulesTab = new Tab("Modules"  , moduleBox);
		Tab recordsTab = new Tab("Records" , recordsBox);
		
		tabPane.getTabs().add(studentTab);
		tabPane.getTabs().add(modulesTab);
		tabPane.getTabs().add(recordsTab);
		tabPane.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);
		tabPane.setTabMinWidth(116);
		
		VBox root = new VBox();
		root.getChildren().addAll(tabPane);
		Scene scene = new Scene(root,400,400);
		primaryStage.setScene(scene);
		primaryStage.show();
		} 
	
	public static void main(String[] args) {
		launch(args);
	}
}
