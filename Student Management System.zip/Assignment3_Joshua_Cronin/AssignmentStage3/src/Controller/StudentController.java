//Joshua Cronin R00200811
package Controller;

import java.time.LocalDate;
import java.util.ArrayList;

import JoshLibrary.PopUpDisplay;
import Model.Student;
import Model.StudentList;
import Model.StudentModule;
import View.RemoveStudent;





public class StudentController {
	
	private StudentList studentList;
	
	public StudentController(){
		studentList = new StudentList();
	}
	
	// Returns the student list 
	public StudentList getStudentList() {
		return studentList;
	}
	
	public void sortStudentModulesList(String sName, String sortType){
		Student selectedStudent = studentList.getStudentByName(sName);
		selectedStudent.sortModules(sortType);
	}
	
	//Adds a student to the list
	public void addStudentToList(String sName,String sId, LocalDate sDOB)
	{
		Student s = new Student(sName, sId, sDOB);
		studentList.addStudent(s);
	}
	
	
	//Adds a module to a student base off of the students name
	public void addModuleToStudent(String sName, String mName, int grade) {
		Student currentStudent = studentList.getStudentByName(sName);
		System.out.println("Current Student:" + currentStudent);
		if (currentStudent != null) {
			System.out.println("mName and grade: " + mName + grade);
			StudentModule sm = new StudentModule(mName, grade);
			currentStudent.addModuleToStudent(sm);
		}
	}
	
	// Gets the student list as a string
	public String getListStudent()
	{
		String allStudent="\0";
		for (int i = 0; i < studentList.getSize(); i++)
		{
			allStudent = allStudent + studentList.getStudent(i);	
		}	
		return allStudent;
	}
	
	//Gets the module list as a string
	public String getListStudentModulesString (String sName)
	{
		String allStudentModules="\0";
		Student selectedStudent = studentList.getStudentByName(sName);
		ArrayList <StudentModule> studentModules = selectedStudent.getStudentModule();
		for (int i = 0; i < selectedStudent.getStudentModuleSize(); i++)
		{
			allStudentModules = allStudentModules + studentModules.get(i);	
		}	
		return allStudentModules;
	}
	
	//Removes a student by name
		public Student getStudentFromList(String sName) {
			Student foundStudent = studentList.getStudentByName(sName);
			return foundStudent;
		}
	
	//Removes a student by name
	public void removeStudentFromList(String sName) {
		
		studentList.remStudentByName(sName);
	}
	
	//Creates a pop-up menu
	public void removeStudentPopUp() {
		studentList.remStudentByName(RemoveStudent.display(studentList));
	}
    
	//Loads the data
    public void loadSerializable() {
    	studentList.loadAllList();
    }
    
    //saves the data
    public void saveSerializable() {
    	studentList.saveList();
    	PopUpDisplay.display("Saved", "File saved");
    }
    
    //Checks for saved data
    public boolean checkForSavedList(){
    	loadSerializable();
    	if(studentList.getList().isEmpty()){
    		return false;
    	}
    	else {
    		return true;
    	}
    }
    
    //Checks for valid Student input
	public boolean checkForValidStudentInput(boolean validNameCheck, boolean validNumberCheck, LocalDate date) {
		if(validNameCheck) {
    		return false;
    	}
    	else if(validNumberCheck) {
    		return false;
    	}
    	else if(date == null) {
    		return false;
    	}
    	 
    	return true;
    }
	
	//Checks for valid Module input
	public String checkForModuleInput(boolean validStudentCheck, boolean validNameCheck, int gradeCheck) {
		if(validStudentCheck) {
    		return "Please select a Student";
    	}
    	if(validNameCheck) {
    		return "Please select a module name";
    	}
    	if(100 < gradeCheck || gradeCheck < 0) {
    		return "Please select a number between 0 and 100";
    	}
    	 
    	return "Module added successfully";
    }
}
