package Controller;

import java.util.Comparator;
import Model.StudentModule;


public class GradeComparator implements Comparator<StudentModule> {

	public int compare (StudentModule m1, StudentModule m2) {
		  Integer grade1 = m1.getGrade();
		  Integer grade2 = m2.getGrade();
		  return grade1.compareTo(grade2);
	  }

}
