package Controller;

import java.util.Comparator;

import Model.StudentModule;


public class ModuleNameComparator implements Comparator<StudentModule> {

	public int compare (StudentModule m1, StudentModule m2) {
		  String mn1 = m1.getName();
		  String mn2 = m2.getName();
		  return mn1.compareTo(mn2);
	}
}