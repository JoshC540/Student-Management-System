//Joshua Cronin R00200811
package View;

import javafx.stage.Stage;
import javafx.scene.control.ListView;
import Model.StudentList;
import javafx.collections.ObservableList;
import javafx.scene.control.SelectionMode;
import javafx.stage.Modality;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.geometry.Pos;

public class RemoveStudent {
	
	static String selected;
	static ListView<String> listView;
	static ObservableList<String> listSelected;
	
	public static String display(StudentList sl) { 
		
		listView = new ListView<>();
		Stage window = new Stage();
		Button removeBtn = new Button("Remove");
		
		
		//Block events to other windows
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Select Student for removal");
		window.setMinWidth(350);
		
		// add cars to the list view
		for (int i = 0; i<sl.getSize(); i++)
		{
			listView.getItems().add(sl.getStudent(i).getName());	
		}	
		listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		
		removeBtn.setOnAction(e -> {
			listSelected = listView.getSelectionModel().getSelectedItems();
			selected = listSelected.get(0).toString();
			window.close();
		});
		
		VBox layout = new VBox(10);
		layout.getChildren().addAll(listView, removeBtn);
		layout.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.showAndWait();
		
		return selected;
		
		}
}
