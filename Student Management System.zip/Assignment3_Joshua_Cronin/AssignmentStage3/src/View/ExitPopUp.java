//Joshua Cronin R00200811
package View;

import Controller.StudentController;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label; 
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.stage.Modality;

public class ExitPopUp {
   
    
public static void display(StudentController studentControl)
{
	Stage popupwindow=new Stage();
      
	popupwindow.initModality(Modality.APPLICATION_MODAL);
	popupwindow.setTitle("Save");
        
	Label successMessage = new Label("Would you like to save before exiting?"); 
	Button closeBtn = new Button("Quit without saving");
	Button saveBtn = new Button("Quit and save");
     
	closeBtn.setOnAction(e -> 
	System.exit(0)
	);
	
	saveBtn.setOnAction(e -> {
		studentControl.saveSerializable();
		System.exit(0);
		}
	);
	HBox buttons = new HBox(10);
	buttons.getChildren().addAll(saveBtn, closeBtn);
	buttons.setAlignment(Pos.CENTER);
     
	VBox layout= new VBox(10); 
	layout.getChildren().addAll(successMessage, buttons); 
	layout.setAlignment(Pos.CENTER);  
	Scene root = new Scene(layout, 300, 250);
    popupwindow.setScene(root);
    popupwindow.showAndWait();
       
	}
}


